#ifndef _ACTOR_H_
#define _ACTOR_H_

#include "GraphObject.h"
class StudentWorld;

// Students:  Add code to this file, actor.cpp, StudentWorld.h, and StudentWorld.cpp

class Actor : public GraphObject
{
public:
	Actor(StudentWorld* ptr, int id, int x, int y);
	virtual ~Actor();
	virtual void doSomething();
	bool isStillAlive();	
	StudentWorld* getWorld();
	void setAlive(bool m);
	bool fire(int type, int firedBy); //pure virtual because only want playership 
							//and aliens to fire //CAN I JUST HAVE ONE FIRE FUNCTION?
private:
	bool m_alive;
	StudentWorld* m_StudentWorld;//pg23 hint at bottom
};

class PlayerShip : public Actor 
{
public:
	PlayerShip(StudentWorld* ptr);
	virtual ~PlayerShip();
	virtual void doSomething();
	//virtual void fire();
private:
	int m_torpedos;
	int m_hp;
	bool fired;
};

class Star : public Actor
{
public:
	Star(StudentWorld* ptr);
	virtual ~Star();
	virtual void doSomething();
private:
};

class Alien : public Actor
{
public:
	//virtual void doSomething();
private:
};

class Nachling : public Alien
{
public:
	//virtual void doSomething();
private:
};

class NormalNachling : public Nachling
{
public:
private:
};

class WealthyNachling : public Nachling
{
public:
private:
};

class Smallbot : public Alien
{
public:
	//virtual void doSomething();
private:
};

class Bullet :public Actor
{
public:
	Bullet(StudentWorld* ptr, int bulletType, int x, int y, int firedBy); 
	void doSomething();
private:
	int m_firedBy;
	int m_bulletType;//to be used in doSomething to determine damage
};

class SepticBullet : public Bullet
{
public:
	SepticBullet(StudentWorld* ptr, int x, int y, int firedBy);
private:
};

class FlatulenceTorpedo :public Bullet
{
public:
	FlatulenceTorpedo(StudentWorld* ptr, int x ,int y, int firedBy);
private:
};

class Goodie : public Actor
{
public:
	//virtual void doSomething();
private:
};

class TorpedoGoodie : public Goodie
{
public:
private:
};

class EnergyGoodie : public Goodie
{
public:
private:
};

class FreeShipGoodie : public Goodie
{
public:
private:
};


#endif // _ACTOR_H_