#include "actor.h"

#include "StudentWorld.h"
//ACTOR IMPLEMENTATION
Actor::Actor(StudentWorld* ptr, int id, int x, int y)//does every actor need a pointer?
	: GraphObject(id, x, y), m_alive(true), m_StudentWorld(ptr) 
{
	setVisible(true);
	}

Actor::~Actor()
{}

void Actor::setAlive(bool m)
{
	m_alive = m;
}

bool Actor::isStillAlive()
{
	return m_alive;
}
bool Actor::fire(int type, int firedBy)//alein(2) player(1)
{
	if (type != IID_BULLET && type != IID_TORPEDO)
		return false;
	if (firedBy != 1 && firedBy != 2)
		return false;
	if (firedBy == 1)
		getWorld()->addActor(type, getX(), getY()+1, firedBy);
	if (firedBy == 2)
		getWorld()->addActor(type, getX(), getY()-1, firedBy);
	return true;
}

void Actor::doSomething()
{}

StudentWorld* Actor::getWorld()
{
	//m_StudentWorld = ptrToShip;
	return m_StudentWorld;
}

//PLAYER SHIP IMPLEMENTATION
PlayerShip::PlayerShip(StudentWorld* ptr)
	: Actor(ptr, IID_PLAYER_SHIP, VIEW_WIDTH/2, 1), m_hp(50), fired(false), m_torpedos(0)
{
}

PlayerShip::~PlayerShip()
{}

void PlayerShip::doSomething()
{
	int key;
	if (getWorld()->getKey(key))//WHY DOESNT IT WORK AS SMOOTHLY
	{
		//user hit a key this tick
		switch (key)
		{
		case KEY_PRESS_LEFT://move player to the left
			if (getX() > 0)
				moveTo(getX()-1, getY());
			break;
		case KEY_PRESS_RIGHT://move player to the right
			if (getX() < VIEW_WIDTH-1)
				moveTo(getX()+1, getY());
			break;
		case KEY_PRESS_UP://move player up
			if (getY()< VIEW_HEIGHT-1)
				moveTo(getX(), getY()+1);
			break;
		case KEY_PRESS_DOWN://move player down
			if (getY() > 0)
				moveTo(getX(), getY()-1);
			break;
		case KEY_PRESS_SPACE:
			if (fired)
				fired = false;
			else
			{
				fire(IID_BULLET, 1);//fire and set fired to true
				fired = true;
			}
			break;
		case KEY_PRESS_TAB:
			if (m_torpedos > 0)
			{
				if (fired)
					fired = false;
				else
				{
					fire(IID_TORPEDO, 1);
					fired = true;
					m_torpedos--;
				}
			}
			break;	
		}		
	}
	else 
		fired = false;
	return;//for (int i = 0; i < m_actors.size(); i++)
}

//STAR IMPLEMENTATION
Star::Star(StudentWorld* ptr)//constructor
	:Actor(ptr, IID_STAR, rand() % 30, VIEW_HEIGHT-1)
{
	
}

void Star::doSomething()
{
	if (getY() >= 0)
		moveTo(getX(), getY()-1);
	else
	{
		setVisible(false);
		setAlive(false);
		//StudentWorld move() should delete it
	}	
	return;
}

Star::~Star()
{}


//BULLET IMPLEMENTATION
Bullet::Bullet(StudentWorld* ptr, int bulletType, int x, int y, int firedBy)
	: Actor(ptr, bulletType, x, y), m_bulletType(bulletType) , m_firedBy(firedBy)//1 is playership, 2 is alien
{}

void Bullet::doSomething()
{
	if (m_firedBy == 1)
		moveTo(getX(), getY()+1);
	if (m_firedBy == 2)
		moveTo(getX(), getY()-1);
	return;
}
//SEPTIC BULLET IMPLEMENTATION
SepticBullet::SepticBullet(StudentWorld* ptr, int x, int y, int firedBy)
	: Bullet(ptr, IID_BULLET, x, y, firedBy)
{}

 //FLATULENCE TORPEDO IMPLEMENTATION
FlatulenceTorpedo::FlatulenceTorpedo(StudentWorld* ptr, int x, int y, int firedBy)
	: Bullet(ptr, IID_TORPEDO, x, y, firedBy)
{}
// Students:  Add code to this file (if you wish), actor.h, StudentWorld.h, and StudentWorld.cpp