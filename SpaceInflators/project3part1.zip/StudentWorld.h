#ifndef _STUDENTWORLD_H_
#define _STUDENTWORLD_H_

#include "GameWorld.h"
#include "GameConstants.h"
#include "actor.h"
#include <vector>
#include <stdlib.h>
#include <time.h>
using namespace std;
// Students:  Add code to this file, StudentWorld.cpp, actor.h, and actor.cpp
class Actor;
class StudentWorld : public GameWorld
{
public:

	virtual void init();
   

	virtual int move();
    

	virtual void cleanUp();
	
    bool addActor(int type, int x, int y, int firedBy);
	~StudentWorld();
private:
	vector<Actor*> m_actors;
	int m_nStars;
	PlayerShip* ptrToShip;
	int m_nActiveAliens;

};

#endif // _GAMEWORLD_H_
