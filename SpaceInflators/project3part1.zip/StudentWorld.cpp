#include "StudentWorld.h"
#include "actor.h"
GameWorld* createStudentWorld()
{
    return new StudentWorld();
}

StudentWorld::~StudentWorld()
{
	delete ptrToShip;//is this necessary?
	for (int i = 0; i < m_actors.size(); i++)
	{
		delete m_actors[i];
		m_actors.erase(m_actors.begin()+i);
	}
}

bool StudentWorld::addActor(int type, int x, int y, int firedBy)//fired by alien(2) or player(1) or not fired (0) 
{
	if (type < 1 || type > 8)//id numbers for all actors except playership and star
		return false;
	if (firedBy < 0 || firedBy > 2)
		return false;
	switch (type)
	{
	case IID_NACHLING:
		//m_actors.push_back(new NormalNachling(this));
		//break;
	case IID_WEALTHY_NACHLING:
		break;
	case IID_SMALLBOT:
		break;
	case IID_BULLET:
		m_actors.push_back(new SepticBullet(this, x, y, firedBy));
		break;
	case IID_TORPEDO:
		m_actors.push_back(new FlatulenceTorpedo(this, x, y, firedBy));
		break;
	case IID_FREE_SHIP_GOODIE:
		break;
	case IID_ENERGY_GOODIE:
		break;
	case IID_TORPEDO_GOODIE:
		break;
	return true;
	}
	return true;
}

void StudentWorld::init()
{
		ptrToShip = new PlayerShip(this);
}
int StudentWorld::move()
{
		//ADD NEW ALIENS OR STARS  
		int random = rand() % 100;
		if (random < 33)
		{
			m_actors.push_back(new Star(this));
			m_nStars++;
		}
		//UPDATE THE GAME STATUS LINE

		//GIVE EACH ACTOR A CHANCE TO DO SOMETHING
		if (ptrToShip->isStillAlive())
			ptrToShip->doSomething();
		for (int i = 0; i < m_actors.size(); i++)
		{
			if (m_actors[i]->isStillAlive() == true)
				m_actors[i]->doSomething();
		}
		for (int i = 0; i <m_actors.size(); i++)//WHY DOES THIS MAKE IT CRASH
		{
			if (m_actors[i]->isStillAlive() == false)
			{
				delete m_actors[i];
				m_actors.erase(m_actors.begin()+i);
			}
		}


		return GWSTATUS_CONTINUE_GAME;
		//decLives();
        //return GWSTATUS_PLAYER_DIED;// This code is here merely to allow the game to build, run, and terminate after hitting enter a few times 
    }

void StudentWorld::cleanUp()
{
	delete ptrToShip;//is this necessary?
	for (int i = 0; i < m_actors.size(); i++)
	{
		delete m_actors[i];
		m_actors.erase(m_actors.begin()+i);
	}
}

// Students:  Add code to this file (if you wish), StudentWorld.h, actor.h and actor.cpp